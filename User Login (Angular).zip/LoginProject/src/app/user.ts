export class User {
    userId!:string;
    password!:string;
}
